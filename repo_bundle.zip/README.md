# Single-Image Super-Resolution: reproducibility material

This repository accompanies the review article *Fidelity, Perception and Efficiency in Single-Image Super-Resolution: A Comprehensive Review of Architectures and Generative Priors*. It contains everything needed to regenerate the visual comparisons (Figs. 10 and 11), the efficiency measurements, and the schematic figures.

All quantitative values in the comparison tables of the article are taken from the cited publications. Only the visual comparisons and the efficiency measurements listed below were produced for the article.

## Contents

| Path | Purpose |
|---|---|
| `fig10_and_efficiency_gpu.ipynb` | Fig. 10 (Urban100, classical x4) and parameters/FLOPs/latency/peak memory (GPU) |
| `fig11_realsr_comparison.ipynb` | Fig. 11 (RealSR, real-world x4) |
| `results/fig10_metrics.json` | PSNR/SSIM of every Fig. 10 column, crop boxes, protocol |
| `results/fig11_metrics.json` | PSNR/SSIM (whole image and crop) of every Fig. 11 column, crop boxes, protocol |
| `results/eff_*.json` | Parameters, FLOPs and latency measured for PFT, MambaIR, MambaIRv2 |
| `figure_sources/` | TikZ sources of the schematic figures (compile with `pdflatex`) |

## Fig. 10 – classical x4 SR on Urban100

* Images: Urban100 `img_062`, `img_092`. HR is cropped to a multiple of 4; LR is produced with MATLAB-compatible bicubic downsampling (BasicSR `imresize`).
* Models and weights (official releases):
  * HAT – `HAT_SRx4.pth` (XPixelGroup/HAT, `options/test/HAT_SRx4.yml`)
  * PFT – `003_PFT_SRx4_finetune.pth` (LabShuHangGU/PFT-SR, `options/test/003_PFT_SRx4_finetune.yml`)
  * MambaIR – `MambaIR_classicSRx4.pth` (csguoh/MambaIR, `options/test/mambair/test_MambaIR_SR_x4.yml`)
  * SRResNet, IMDN, RRDB (ESRGAN generator trained with L1), SwinIR-S, SwinIR – official pretrained x4 weights of the respective authors
* The notebook runs HAT, PFT and MambaIR itself. The outputs of SRResNet, IMDN, RRDB, SwinIR-S and SwinIR, produced with the official test scripts of their repositories, are read through `EXISTING_OUTPUTS` in the configuration cell.
* Hardware: HAT, PFT and MambaIR were run on an NVIDIA L4 GPU. For MambaIR the selective scan used a numerically equivalent PyTorch reference implementation (`MAMBA_BACKEND = reference`), which changes run time, not the output.
* Metrics: PSNR and SSIM on the Y channel (ITU-R BT.601, BasicSR), whole image, 4-pixel border excluded. SSIM uses an 11x11 Gaussian window with sigma = 1.5.
* Enlarged regions (HR pixels, x, y, w, h): `img_062` (40, 430, 200, 150); `img_092` (300, 260, 200, 150).
* Bicubic column: OpenCV bicubic upsampling of the bicubic-downsampled LR input.

## Fig. 11 – real-world x4 SR on RealSR

* Inputs: RealSR test crops `Canon_026`, `Nikon_031`, `Canon_041` (128x128 LR, 512x512 registered HR), as distributed with OSEDiff (`preset/datasets/benchmark_realsr`).
* Models and weights:
  * BSRGAN – `BSRGAN.pth` (cszn/KAIR release v1.0)
  * Real-ESRGAN – `RealESRGAN_x4plus.pth` (xinntao/Real-ESRGAN release v0.1.0)
  * Real-SwinIR – `003_realSR_BSRGAN_DFO_s64w8_SwinIR-M_x4_GAN.pth` (JingyunLiang/SwinIR release v0.0)
  * ResShift (journal version, 4 steps) – `resshift_realsrx4_s4_v3.pth` and `autoencoder_vq_f4.pth` (zsyOAOA/ResShift release v2.0)
  * SinSR (1 step) – `SinSR_v1.pth` (wyf0912/SinSR release v1.0)
  * OSEDiff (1 step) – official result images released by the OSEDiff authors
* Metrics: as for Fig. 10; crop values are computed on the enlarged region without border removal.
* Enlarged regions (HR pixels, x, y, w, h): `Canon_026` (150, 60, 200, 150); `Nikon_031` (220, 20, 280, 210); `Canon_041` (176, 150, 200, 150).

## Running

Open the notebooks in Jupyter or Google Colab and run all cells. They clone the official repositories, download the weights listed above, prepare the data, run the models, compute the metrics and write the figures. A CUDA GPU is required for the efficiency section and recommended for Fig. 10.

## Licence and third-party material

The notebooks and figure sources are released for research use. Model code, weights and datasets remain under the licences of their original authors.
